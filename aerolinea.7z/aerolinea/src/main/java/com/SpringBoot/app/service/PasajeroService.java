package com.SpringBoot.app.service;

import com.SpringBoot.app.entity.Pasajero;

public interface PasajeroService {

	public Pasajero guardarPasajero(Pasajero pasajero);
}
