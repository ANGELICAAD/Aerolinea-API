package com.SpringBoot.app.service;

import com.SpringBoot.app.entity.Tiquete;

public interface TiqueteService {

	public Tiquete guardarTiquete(Tiquete tiquete);
}
